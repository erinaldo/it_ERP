﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Core.Erp.Info.Produc_Cirdesus;
using Core.Erp.Business.Produc_Cirdesus;
using Core.Erp.Info.General;
using Core.Erp.Business.General;
using Core.Erp.Winform.Controles;
using Core.Erp.Info.Roles;
using Core.Erp.Business.Roles;
using DevExpress.XtraEditors;
using Infragistics.Win.UltraWinGrid;
using Core.Erp.Reports.Produc_Cirdesus;
//verson 24062013 1635
namespace Core.Erp.Winform.Produc_Cirdesus
{
    public partial class FrmPrd_GrupoTrabajoMantenimiento : Form
    {
        public FrmPrd_GrupoTrabajoMantenimiento()
        {
            try
            {
             InitializeComponent();
                cmb_empleado.DataSource = BusEmpleado.Obtener_Empleado_persona(param.IdEmpresa);
                EVENT_FrmPrd_GrupoTrabajoMantenimiento_FormClosing += new delegate_FrmPrd_GrupoTrabajoMantenimiento_FormClosing(FrmPrd_GrupoTrabajoMantenimiento_EVENT_FrmPrd_GrupoTrabajoMantenimiento_FormClosing);
                UCObra.Event_UCObra_SelectionChanged += new UCPrd_Obra.delegadoUCObra_SelectionChanged(UCObra_Event_UCObra_SelectionChanged);
                UCObra.Event_UCObra_Validating += new UCPrd_Obra.delegadoUCObra_Validating(UCObra_Event_UCObra_Validating);
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }
            
        }

        void FrmPrd_GrupoTrabajoMantenimiento_EVENT_FrmPrd_GrupoTrabajoMantenimiento_FormClosing(object sender, FormClosingEventArgs e){}

        void UCObra_Event_UCObra_Validating(object sender, CancelEventArgs e)
        {
            try
            {
              setearcombos();
            }
            catch (Exception ex)
            { 
                Log_Error_bus.Log_Error(ex.ToString());
            }

        }

        private void FrmPrd_GrupoTrabajoMantenimiento_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                     EVENT_FrmPrd_GrupoTrabajoMantenimiento_FormClosing(sender, e);
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }
  

        }

        #region variables
        tb_sis_Log_Error_Vzen_Bus Log_Error_bus = new tb_sis_Log_Error_Vzen_Bus();
        //DELEGADO
        public delegate void delegate_FrmPrd_GrupoTrabajoMantenimiento_FormClosing(object sender, FormClosingEventArgs e);
        public event delegate_FrmPrd_GrupoTrabajoMantenimiento_FormClosing EVENT_FrmPrd_GrupoTrabajoMantenimiento_FormClosing;


        //instancias de Cabecera de GT
        prd_GrupoTrabajo_Info InfoCabeceraGT_Nueva = new prd_GrupoTrabajo_Info(); //esta es para el get
        prd_GrupoTrabajo_Bus BusCabeceraGT = new prd_GrupoTrabajo_Bus();

        //instancias de Detalle GT
        prd_GrupoTrabajoDetalle_Bus BusDetalleGT = new prd_GrupoTrabajoDetalle_Bus();
        List<prd_GrupoTrabajoDetalle_Info> LmInfoDetalleGT_Original = new List<prd_GrupoTrabajoDetalle_Info>(); //esta es del set
        List<prd_GrupoTrabajoDetalle_Info> _LmInfoDetalleGT_Nueva = new List<prd_GrupoTrabajoDetalle_Info>(); //esta es del get
        DataTable dt = new DataTable("detalle");
        List<prd_GrupoTrabajoDetalle_Info> DetGT = new List<prd_GrupoTrabajoDetalle_Info>();

        //instancias de centro de costo
        UCPrd_Obra UCObra = new UCPrd_Obra();

        //instancias de modelo produccion x centro costo
        prd_ProcesoProductivo_x_prd_obra_Bus BusModeloxCC = new prd_ProcesoProductivo_x_prd_obra_Bus();
        prd_EtapaProduccion_Bus BusEtapasProduccion = new prd_EtapaProduccion_Bus();

        //instancia de orden taller
        prd_OrdenTaller_Bus BusOT = new prd_OrdenTaller_Bus();
        DataTable dtOT = new DataTable("detalle");
        List<prd_OrdenTaller_Info> lmOT = new List<prd_OrdenTaller_Info>();
        //sucursal
        UCIn_Sucursal_Bodega UCSuc = new UCIn_Sucursal_Bodega();

        //instancias de empleado
        ro_Empleado_Bus BusEmpleado = new ro_Empleado_Bus();

        //instancias generales
        cl_parametrosGenerales_Bus param = cl_parametrosGenerales_Bus.Instance;
        private Cl_Enumeradores.eTipo_action Accion;
        #endregion

        public void set_Accion(Cl_Enumeradores.eTipo_action iAccion)
        {
            try
            {


                Accion = iAccion;
                switch (Accion)
                {
                    case Cl_Enumeradores.eTipo_action.grabar:
                        this.btnGrabar.Text = "Grabar Registro";
                        this.btnGrabarySalir.Text = "Grabar y Salir";
                        this.lblAnulado.Visible = false;
                        this.txt_numGrupo.Text = "0";


                        break;
                    case Cl_Enumeradores.eTipo_action.actualizar:
                        this.btnGrabar.Text = "Actualizar Registro";
                        this.btnGrabarySalir.Text = "Actualizar y Salir";
                        this.UCObra.UC_Obra.Enabled = false;
                        this.UltraCmbOrdenTaller.Enabled = false;
                        this.UCSuc.cmb_sucursal.Enabled = false;
                        break;
                    case Cl_Enumeradores.eTipo_action.consultar:
                        this.btnGrabar.Enabled = false;
                        this.btnGrabarySalir.Enabled = false;
                        this.UCObra.UC_Obra.Enabled = false;
                        this.UltraCmbOrdenTaller.Enabled = false;
                        this.UCSuc.cmb_sucursal.Enabled = false;
                        break;

                    case Cl_Enumeradores.eTipo_action.borrar:
                        this.btnGrabar.Enabled = false;
                        this.btnGrabarySalir.Enabled = false;
                        this.UCObra.UC_Obra.Enabled = false;
                        this.UltraCmbOrdenTaller.Enabled = false;
                        this.UCSuc.cmb_sucursal.Enabled = false;
                        this.btn_Anular.Visible = true;
                        this.sep1.Visible = true;
                        break;
                    default:
                        break;
                }

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }

        }

        public void iniciar()
        {
            try
            {
               //_Accion = Cl_Enumeradores.eTipo_action.actualizar;
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }

        }

        private void iniciar_controles()
        {
            try
            {
                UCObra.cargaCmb_Obra();
                PanelObra.Controls.Add(UCObra);
                UCObra.Dock = DockStyle.Fill;
                UCObra.Event_UCObra_SelectionChanged += new UCPrd_Obra.delegadoUCObra_SelectionChanged(UCObra_Event_UCObra_SelectionChanged);
                cargaCmbE_Lider();

                UCSuc.TipoCarga = Cl_Enumeradores.eTipoFiltro.Normal;
                UCSuc.cargar_sucursal(param.IdEmpresa);
                panelSucursal.Controls.Add(UCSuc);
                UCSuc.Dock = DockStyle.Fill;

                //size y location de controles
                UCObra.label.Location = new Point(10, 0);
                UCObra.UC_Obra.Location = new Point(66, 1);
                UCObra.UC_Obra.Size = new System.Drawing.Size(290, 21);
                UCSuc.label1.Location = new Point(10, 4);
                UCSuc.cmb_sucursal.Location = new Point(66, 1);
                UCSuc.cmb_sucursal.Size = new Size(290, 21);
                UCSuc.cmb_sucursal.DropDownStyle = ComboBoxStyle.DropDown;
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        void setearcombos()
        {
            try
            {
                ultraCmbEEtapaProduccion.DataSource = null;
                ultraCmbEEtapaProduccion.Text = "";
                ultraCmbEModeloProductivo.DataSource = null;
                ultraCmbEModeloProductivo.Text = "";
                UltraCmbOrdenTaller.DataSource = null;
                UltraCmbOrdenTaller.Text = "";

                if (UCObra.get_item_info() != null)
                {
                    cargaCmbE_ModeloProduccion(UCObra.get_item());

                }



            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }


        }

        private void cargaCmbE_ModeloProduccion(string CodObra)
        {
            try
            {
                ultraCmbEModeloProductivo.DataSource = BusModeloxCC.ObtenerProcesProductivo_x_CentroCosto(param.IdEmpresa, CodObra);
                this.ultraCmbEModeloProductivo.DisplayMember = "NombreModelo";
                this.ultraCmbEModeloProductivo.ValueMember = "IdProcesoProductivo";
                this.ultraCmbEEtapaProduccion.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest;
                this.ultraCmbEEtapaProduccion.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains;

                if (ultraCmbEModeloProductivo.SelectedIndex == -1)
                    ultraCmbEModeloProductivo.SelectedIndex = 0; //siempre se setea el primero

                if (ultraCmbEModeloProductivo.Value == null)
                    ultraCmbEModeloProductivo.Text = "";

                else
                {
                    cargaCmbE_EtapasProduccion(Convert.ToInt32(ultraCmbEModeloProductivo.Value));
                    cargaCmbE_OrdenTaller(CodObra);
                }
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void cargaCmbE_EtapasProduccion(int IdModelo)
        {
            try
            {
                if (IdModelo != null)
                {

                    ultraCmbEEtapaProduccion.DataSource = BusEtapasProduccion.ObtenerListaEtapas(param.IdEmpresa, IdModelo);
                    if (ultraCmbEEtapaProduccion.DataSource != null)
                    {
                        this.ultraCmbEEtapaProduccion.DisplayMember = "NombreEtapa";
                        this.ultraCmbEEtapaProduccion.ValueMember = "IdEtapa";
                        this.ultraCmbEEtapaProduccion.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest;
                        this.ultraCmbEEtapaProduccion.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains;
                        if (ultraCmbEEtapaProduccion.SelectedIndex == -1)
                            ultraCmbEEtapaProduccion.SelectedIndex = 0;
                    }
                }
                else
                    ultraCmbEEtapaProduccion.Text = "";
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void cargaCmbE_OrdenTaller(string CodObra)
        {
            try
            {
                lmOT = BusOT.ObtenerListaOT_x_CentroCosto(param.IdEmpresa, CodObra);

                //dtOT.Columns.Add("IdOrdenTaller", typeof(int));
                //dtOT.Columns.Add("NumeroOT", typeof(int));
                //dtOT.Columns.Add("Codigo", typeof(string));
                //dtOT.Columns.Add("Producto", typeof(string));
                //dtOT.Columns.Add("Cantidad", typeof(double));
                //dtOT.Columns.Add("Peso Unitario", typeof(double));
                //dtOT.Columns.Add("Peso Total", typeof(double));

                //dtOT.AcceptChanges();
                //this.UltraCmbOrdenTaller.DataSource = dtOT;

                if (lmOT.Count != 0)
                {
                    this.UltraCmbOrdenTaller.DataSource = lmOT;
                    if (UltraCmbOrdenTaller.SelectedIndex == -1)
                        UltraCmbOrdenTaller.SelectedIndex = 0;
                    //foreach (var item in lmOT)
                    //{
                    //    DataRow filas;
                    //    filas = dtOT.NewRow();
                    //    filas[0] = item.IdOrdenTaller;
                    //    filas[1] = item.NumeroOT;
                    //    filas[2] = item.Codigo;
                    //    filas[3] = item.NomProducto;
                    //    filas[4] = item.CantidadPieza;
                    //    filas[5] = item.PesoUnitario;
                    //    filas[6] = item.TotalPeso;

                    //    dtOT.Rows.Add(filas);
                    //    dtOT.AcceptChanges();
                    //}
                }

                this.UltraCmbOrdenTaller.DisplayMember = "Codigo";
                this.UltraCmbOrdenTaller.ValueMember = "IdOrdenTaller";
                this.UltraCmbOrdenTaller.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest;
                this.UltraCmbOrdenTaller.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains;


            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void cargaCmbE_Lider()
        {
            try
            {
                
                 ultraCmbELiderGrupo.DataSource = BusEmpleado.Obtener_Empleado_persona(param.IdEmpresa);
                 this.ultraCmbELiderGrupo.DisplayMember = "NomCompleto";
                this.ultraCmbELiderGrupo.ValueMember = "IdEmpleado";
                this.ultraCmbELiderGrupo.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest;
                this.ultraCmbELiderGrupo.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains;

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }



        void UCObra_Event_UCObra_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                setearcombos();
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }


        }


        public void setCab(prd_GrupoTrabajo_Info info)
        {
            try
            {
                InfoCabeceraGT_Nueva = info;
                txt_numGrupo.Text = info.IdGrupoTrabajo.ToString().Trim();
                txt_nomGrupo.Text = info.Descripcion.Trim();
                UCObra.set_item(info.CodObra);
                cargaCmbE_ModeloProduccion(info.CodObra);
                cargaCmbE_OrdenTaller(info.CodObra);
                UltraCmbOrdenTaller.Value = info.IdOrdenTaller;
                ultraCmbELiderGrupo.Value = info.IdLider;
                ultraCmbEEtapaProduccion.Value = info.IdEtapa;
                UCSuc.cmb_sucursal.SelectedValue = info.IdSucursal;
                
                if (info.Estado == "I")
                {
                    lblAnulado.Visible = true;
                    chkEstado.Checked = false;
                }
                else
                    chkEstado.Checked = true;

               
                setDet(info.CodObra, info.IdGrupoTrabajo);
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        public void setDet(string IdCentroCosto, decimal IdGrupoTrabajo)
        {
            try
            {
                LmInfoDetalleGT_Original = BusDetalleGT.ObtenerGrupoTrabDetalle(IdGrupoTrabajo, param.IdEmpresa, param.IdSucursal);
                carga_gridPre(LmInfoDetalleGT_Original);

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        int sec = 1;
        private void carga_gridPre(List<prd_GrupoTrabajoDetalle_Info> lm)
        {
            try
            {
                if (lm.Count > 0)
                {
                    //ultraGridDetalle.DataSource = lm;
                    //this.ultraGridDetalle.Rows[0].Activation = Activation.NoEdit;

                    //gridCtrlGT.DataSource = lm;

                    foreach (var item in lm)
                    {
                        gridViewGT.AddNewRow();
                        gridViewGT.SetFocusedRowCellValue(colCodObra, item.CodObra);
                        gridViewGT.SetFocusedRowCellValue(colIdEmpleado, item.IdEmpleado);
                        gridViewGT.SetFocusedRowCellValue(colIdEmpresa, item.IdEmpresa);
                        gridViewGT.SetFocusedRowCellValue(colIdGrupotrabajo, item.IdGrupotrabajo);
                        gridViewGT.SetFocusedRowCellValue(colIdSucursal, item.IdSucursal);
                        gridViewGT.SetFocusedRowCellValue(colObservacion, item.Observacion);


                    }

                }
                ///
                /*
                 * 
                 * ultraGridDetalle.DataSource = lm;
                    this.ultraGridDetalle.Rows[0].Activation = Activation.NoEdit;

                dt.Columns.Add("IdEmpresa", typeof(int));
                dt.Columns.Add("IdSucursal", typeof(int));
                dt.Columns.Add("IdGrupotrabajo", typeof(decimal));
                dt.Columns.Add("Secuencia", typeof(int));
                dt.Columns.Add("IdEmpleado", typeof(decimal));
                dt.Columns.Add("Observacion", typeof(string));
                dt.Columns.Add("NombreCompleto", typeof(string));

                dt.AcceptChanges();
                ultraGridDetalle.DataSource = dt;

                if (lm != null)
                {
                    foreach (var item in lm)
                    {
                        DataRow filas;
                        filas = dt.NewRow();
                        filas[0] = param.IdEmpresa;
                        filas[1] = param.IdSucursal;
                        filas[2] = (item.IdGrupotrabajo == null) ? 0 : item.IdGrupotrabajo;
                        filas[3] = (item.Secuencia == null) ? 0 : item.Secuencia;
                        filas[4] = (item.IdEmpleado == null) ? 0 : item.IdEmpleado;
                        filas[5] = (item.Observacion == null) ? "" : item.Observacion;

                        dt.Rows.Add(filas);
                        dt.AcceptChanges();
                    }
                }
                this.ultraGridDetalle.Rows[0].Activation = Activation.NoEdit;   */
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }


        private Boolean getCab()
        {
            try
            {
                InfoCabeceraGT_Nueva.IdEmpresa = param.IdEmpresa;
                InfoCabeceraGT_Nueva.IdSucursal = UCSuc.get_sucursal().IdSucursal;
                InfoCabeceraGT_Nueva.IdGrupoTrabajo = Convert.ToDecimal(txt_numGrupo.Text);
                InfoCabeceraGT_Nueva.CodObra = UCObra.get_item();
                InfoCabeceraGT_Nueva.IdProcesoProductivo = Convert.ToInt32(ultraCmbEModeloProductivo.Value);
                InfoCabeceraGT_Nueva.IdEtapa = Convert.ToInt32(ultraCmbEEtapaProduccion.Value);
                InfoCabeceraGT_Nueva.IdOrdenTaller = Convert.ToInt32(UltraCmbOrdenTaller.Value);
                InfoCabeceraGT_Nueva.IdLider = Convert.ToDecimal(ultraCmbELiderGrupo.Value);
                InfoCabeceraGT_Nueva.Estado = (this.chkEstado.Checked == true) ? "A" : "I";
                InfoCabeceraGT_Nueva.Descripcion = txt_nomGrupo.Text.Trim();
                InfoCabeceraGT_Nueva.FechaCreacion = DateTime.Now;
                return getDet(InfoCabeceraGT_Nueva.IdGrupoTrabajo);
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        private Boolean getDet(decimal IdGrupoTrabajo)
        {
            try
            {
                DetGT = new List<prd_GrupoTrabajoDetalle_Info>();
                _LmInfoDetalleGT_Nueva = new List<prd_GrupoTrabajoDetalle_Info>();
                //for (int i = 0; i < this.ultraGridDetalle.Rows.Count; i++)
                //{
                //    prd_GrupoTrabajoDetalle_Info infodet = new prd_GrupoTrabajoDetalle_Info();
                //    infodet.IdEmpresa = param.IdEmpresa;
                //    infodet.IdSucursal = param.IdSucursal;
                //    infodet.IdGrupotrabajo = IdGrupoTrabajo;
                //    infodet.CodObra = UCObra.get_item();
                //    infodet.Secuencia = i+1;
                //    infodet.IdEmpleado = Convert.ToDecimal(ultraGridDetalle.Rows[i].Cells["IdEmpleado"].Value);
                //    infodet.Observacion = ultraGridDetalle.Rows[i].Cells["Observacion"].Text.ToString().Trim();
                //    _LmInfoDetalleGT_Nueva.Add(infodet);
                //}

                for (int i = 0; i <= gridViewGT.RowCount; i++)
                {
                    prd_GrupoTrabajoDetalle_Info infolider = new prd_GrupoTrabajoDetalle_Info();

                    var row = (prd_GrupoTrabajoDetalle_Info)gridViewGT.GetRow(i);
                    if (row != null)
                    {
                        prd_GrupoTrabajoDetalle_Info info = new prd_GrupoTrabajoDetalle_Info();
                        info.IdEmpleado = row.IdEmpleado;
                        info.NombreCompleto = row.NombreCompleto;
                        info.CodObra = InfoCabeceraGT_Nueva.CodObra;
                        info.IdEmpresa = InfoCabeceraGT_Nueva.IdEmpresa;
                        info.IdGrupotrabajo = InfoCabeceraGT_Nueva.IdGrupoTrabajo;
                        info.IdSucursal = InfoCabeceraGT_Nueva.IdSucursal;

                        info.Observacion = row.Observacion;

                        if (info.IdEmpleado == 0 || info.IdEmpleado == null)
                        {
                            MessageBox.Show("Debe seleccionar un empleado", "Sistema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return false;

                        }
                        else
                            info.IdEmpleado = row.IdEmpleado;
                        DetGT.Add(info);


                    }
                    //if (Accion == Cl_Enumeradores.eTipo_action.grabar
                    //    && i == gridViewGT.RowCount)
                    //{
                    //    infolider.IdEmpleado = (decimal)ultraCmbELiderGrupo.Value;
                    //    infolider.NombreCompleto = BusEmpleado.Obtener_1_Empleado(param.IdEmpresa, infolider.IdEmpleado).pe_nombreCompleto;
                    //    infolider.Observacion = "Lider de Grupo";

                    //}
                }
                DetGT = DetGT.FindAll(var => var.IdEmpleado != (decimal)ultraCmbELiderGrupo.Value);
                //if (Accion  == Cl_Enumeradores.eTipo_action.grabar)
                //{
                prd_GrupoTrabajoDetalle_Info lider = new prd_GrupoTrabajoDetalle_Info();
                lider.IdEmpleado = (decimal)ultraCmbELiderGrupo.Value;
                //lider.NombreCompleto = BusEmpleado.Obtener_1_Empleado(param.IdEmpresa, lider.IdEmpleado).pe_nombreCompleto;
                lider.Observacion = "Lider de Grupo";
                lider.CodObra = InfoCabeceraGT_Nueva.CodObra;
                lider.IdEmpresa = InfoCabeceraGT_Nueva.IdEmpresa;
                lider.IdGrupotrabajo = InfoCabeceraGT_Nueva.IdGrupoTrabajo;
                lider.IdSucursal = InfoCabeceraGT_Nueva.IdSucursal;

                DetGT.Add(lider);
                //}

                _LmInfoDetalleGT_Nueva = DetGT;



                return true;

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                return false;
            }
        }


        #region "Eventos Click de botones"
        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                txt_nomGrupo.Focus();
                if (validaciones() == false)
                {
                    MessageBox.Show("No se Guardó", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    grabar();
                }
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }

        }

        private void btnGrabarySalir_Click(object sender, EventArgs e)
        {
            try
            {
                txt_nomGrupo.Focus();
                    if (validaciones() == false)
                    {
                        MessageBox.Show("No se Guardó", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        grabar();this.Close();
                    }
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }
            
            
        }


        private void btn_Anular_Click(object sender, EventArgs e)
        {
            try
            {
                anular();


            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }
        }
        void anular()
        {
            try
            {
                string msg = "";
                InfoCabeceraGT_Nueva.Estado = "I";
                if (BusCabeceraGT.AnularReactiva(param.IdEmpresa, InfoCabeceraGT_Nueva, ref msg))
                {
                    MessageBox.Show(msg, "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    set_Accion(Cl_Enumeradores.eTipo_action.consultar); lblAnulado.Visible = true;
                }

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }

        }
        private void mnu_salir_Click(object sender, EventArgs e)
        {
            try
            {
               this.Close();
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }  

        }
        #endregion

        private void FrmPrd_GrupoTrabajoMantenimiento_Load(object sender, EventArgs e)
        {
            try
            {
                iniciar_controles();
                carga_gridPre(LmInfoDetalleGT_Original);
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }

        }

        private Boolean validaciones()
        {
            try
            {
                if (UCObra.get_item_info() == null)
                {
                    MessageBox.Show("Debe seleccionar una Obra", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else if (ultraCmbEModeloProductivo.Value == null)
                {
                    MessageBox.Show("Debe seleccionar un Modelo de producción", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else if (this.ultraCmbEEtapaProduccion.Value == null)
                {
                    MessageBox.Show("Debe seleccionar una etapa de producción", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else if (this.UltraCmbOrdenTaller.Value == null)
                {
                    MessageBox.Show("Debe seleccionar una Orden de Taller", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else if (this.ultraCmbELiderGrupo.Value == null)
                {
                    MessageBox.Show("Debe seleccionar un lider para este grupo", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else if (this.txt_nomGrupo.Text == string.Empty)
                {
                    MessageBox.Show("Escriba la Descripcion(Nombre) del Grupo", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                //else if (this.ultraGridDetalle.Rows.Count <=0)
                //{
                //    MessageBox.Show("Debe Ingresar al menos un empleado en el detalle", "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return false;
                //}
                else
                    return getCab();
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        private void grabar()
        {
            try
            {

                
                    //txt_numGrupo.Focus();

                    string msg = "";
                    decimal idgenerada = 0;
                    switch (Accion)
                    {
                        case Cl_Enumeradores.eTipo_action.grabar:
                            if (BusCabeceraGT.GrabarCabeceraDB(param.IdEmpresa, InfoCabeceraGT_Nueva, _LmInfoDetalleGT_Nueva, ref msg, ref idgenerada))
                            {
                                txt_numGrupo.Text = idgenerada.ToString();
                                set_Accion(Cl_Enumeradores.eTipo_action.consultar);
                            }
                            MessageBox.Show(msg, "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        case Cl_Enumeradores.eTipo_action.actualizar:
                            if (BusCabeceraGT.ModificarDB(param.IdEmpresa, InfoCabeceraGT_Nueva, ref msg))
                            {
                                LmInfoDetalleGT_Original = BusDetalleGT.ObtenerGrupoTrabDetalle(InfoCabeceraGT_Nueva.IdGrupoTrabajo, InfoCabeceraGT_Nueva.IdEmpresa, InfoCabeceraGT_Nueva.IdSucursal);
                                _LmInfoDetalleGT_Nueva.ForEach(var => var.CodObra = InfoCabeceraGT_Nueva.CodObra);
                                if (BusDetalleGT.eliminarregistrotabla(LmInfoDetalleGT_Original, param.IdEmpresa, InfoCabeceraGT_Nueva.IdGrupoTrabajo, ref msg))
                                    if (BusDetalleGT.grabarDB(_LmInfoDetalleGT_Nueva, param.IdEmpresa, InfoCabeceraGT_Nueva.IdGrupoTrabajo, ref msg))
                                        txt_numGrupo.Text = InfoCabeceraGT_Nueva.IdGrupoTrabajo.ToString();


                            }
                            gridViewGT.SelectAll();
                            gridViewGT.DeleteSelectedRows();
                            carga_gridPre(_LmInfoDetalleGT_Nueva);

                            MessageBox.Show(msg, "SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        default:
                            break;
                    }
                
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void ultraGridDetalle_InitializeLayout(object sender, Infragistics.Win.UltraWinGrid.InitializeLayoutEventArgs e)
        {
            try
            {
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdEmpleado"].EditorComponent = ultraCmbELiderGrupo;
                    ultraGridDetalle.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.TemplateOnBottom;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdEmpleado"].AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdEmpleado"].AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains;

                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdEmpleado"].Hidden = false;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdEmpresa"].Hidden = true;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdSucursal"].Hidden = true;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["IdGrupotrabajo"].Hidden = true;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["Secuencia"].Hidden = false;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["Observacion"].Hidden = false;
                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["NombreCompleto"].Hidden = true;

                    ultraGridDetalle.DisplayLayout.Bands[0].Columns["Secuencia"].CellActivation = Activation.NoEdit;
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }
            
        }

        private void ultraGridDetalle_AfterRowInsert(object sender, RowEventArgs e)
        {
            try
            {

                ultraGridDetalle.Rows[ultraGridDetalle.Rows.Count - 1].Cells["Secuencia"].Value = ultraGridDetalle.Rows.Count;
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void ultraCmbELiderGrupo_AfterExitEditMode(object sender, EventArgs e)
        {
            try
            {


                ////    if (ultraGridDetalle.Rows.Count <= 0)
                ////    {
                ////        DataRow filas;
                ////        filas = dt.NewRow();
                ////        filas[0] = param.IdEmpresa;
                ////        filas[1] = param.IdSucursal;
                ////        filas[2] = (InfoCabeceraGT_Nueva.IdGrupoTrabajo == null) ? 0 : InfoCabeceraGT_Nueva.IdGrupoTrabajo;
                ////        filas[3] = 1;
                ////        filas[4] = (ultraCmbELiderGrupo.Value != null) ? ultraCmbELiderGrupo.Value : DBNull.Value;
                ////        filas[5] = "LIDER";

                ////        dt.Rows.Add(filas);
                ////        dt.AcceptChanges();

                ////        this.ultraGridDetalle.DataSource = dt;
                ////        this.ultraGridDetalle.Rows[0].Activation = Activation.NoEdit;
                ////    }
                ////    else
                ////        ultraGridDetalle.Rows[0].Cells["IdEmpleado"].Value = ultraCmbELiderGrupo.Value;
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void ultraCmbELiderGrupo_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (ultraCmbELiderGrupo.Value == null)
                {
                    ultraCmbELiderGrupo.Text = "";

                }

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }


        }

        private void UltraCmbOrdenTaller_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (UltraCmbOrdenTaller.Value == null)
                {
                    UltraCmbOrdenTaller.Text = "";

                }
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void ultraCmbEEtapaProduccion_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (ultraCmbEEtapaProduccion.Value == null)
                {
                    ultraCmbEEtapaProduccion.Text = "";

                }

            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
                MessageBox.Show(ex.ToString());
            }
        }

        private void gridViewGT_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode.ToString() == "Delete")
                    gridViewGT.DeleteSelectedRows();
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }

        }

        private void btn_Imprimir_Click(object sender, EventArgs e)
        {
            try
            {
                XPRO_CUS_CID_Rpt009 Xreport = new XPRO_CUS_CID_Rpt009();
                prd_ObtenerReporte_Bus busSpRpt = new prd_ObtenerReporte_Bus();
                List<tbPRO_CUS_CID_Rpt009_Info> data = new List<tbPRO_CUS_CID_Rpt009_Info>();
                data = busSpRpt.OptenerData_spPRD_Rpt_RPRD009(param.IdEmpresa, InfoCabeceraGT_Nueva.IdSucursal, InfoCabeceraGT_Nueva.IdGrupoTrabajo ,param.IdUsuario, param.nom_pc);
                Xreport.loadData(data.ToArray());
                Xreport.ShowPreviewDialog();
            }
            catch (Exception ex)
            {
                Log_Error_bus.Log_Error(ex.ToString());
            }
        }

        //private void ultraCmbELiderGrupo_ValueChanged(object sender, EventArgs e)
        //{
        //    decimal idempleado=-1;
        //    idempleado = (decimal)ultraCmbELiderGrupo.SelectedIndex;
        //    if (idempleado >=0 )
        //        cmb_empleado.DataSource = BusEmpleado.Obtener_Empleado_persona(param.IdEmpresa).FindAll(var => var.IdEmpleado != Convert.ToDecimal(ultraCmbELiderGrupo.Value));


        //    if (Accion == Cl_Enumeradores.eTipo_action.grabar)
        //    {
        //        gridViewGT.SelectAll();
        //        gridViewGT.DeleteSelectedRows();

        //        //int row = 1;
        //        //row = gridViewGT.RowCount;
        //        //for (int i = 0; i < row + 1; i++)
        //        //{
        //        //    gridViewGT.DeleteRow(i);
        //        //}

        //            //DataSource = new List<prd_GrupoTrabajoDetalle_Info>();
        //    }
        //}



    }
}
