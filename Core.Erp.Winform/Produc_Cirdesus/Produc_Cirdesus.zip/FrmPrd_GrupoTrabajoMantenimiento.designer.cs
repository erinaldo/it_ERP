﻿namespace Core.Erp.Winform.Produc_Cirdesus
{
    partial class FrmPrd_GrupoTrabajoMantenimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrd_GrupoTrabajoMantenimiento));
            Infragistics.Win.UltraWinGrid.UltraGridBand ultraGridBand1 = new Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1);
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn15 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("IdEmpleado");
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn16 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("Secuencia", 0);
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn17 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("Observacion", 1);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.gridCtrlGT = new DevExpress.XtraGrid.GridControl();
            this.prdGrupoTrabajoDetalleInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewGT = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colIdEmpresa = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIdSucursal = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCodObra = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cmb_empleado = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.roEmpleadoInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colIdEmpleado1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colpe_nombreCompleto = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIdEmpleado = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIdGrupotrabajo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNombreCompleto = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colObservacion = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSecuencia = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemHyperLinkEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.repositoryItemHyperLinkEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.repositoryItemPictureEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.repository_Producto = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridcombo = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cmb_estado = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.repositoryItemSearchLookUpEdit2View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.ultraGridDetalle = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelSucursal = new System.Windows.Forms.Panel();
            this.PanelObra = new System.Windows.Forms.Panel();
            this.chkEstado = new System.Windows.Forms.CheckBox();
            this.ultraCmbEModeloProductivo = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_numGrupo = new System.Windows.Forms.TextBox();
            this.lblAnulado = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.UltraCmbOrdenTaller = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.ultraCmbELiderGrupo = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.ultraCmbEEtapaProduccion = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_nomGrupo = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripMain = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGrabar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGrabarySalir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Imprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnu_salir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.sep1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Anular = new System.Windows.Forms.ToolStripButton();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridCtrlGT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prdGrupoTrabajoDetalleInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_empleado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roEmpleadoInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repository_Producto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridcombo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_estado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit2View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGridDetalle)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraCmbEModeloProductivo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UltraCmbOrdenTaller)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraCmbELiderGrupo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraCmbEEtapaProduccion)).BeginInit();
            this.toolStripMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.statusStrip1);
            this.panel1.Controls.Add(this.toolStripMain);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(699, 531);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.gridCtrlGT);
            this.panel3.Controls.Add(this.ultraGridDetalle);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 169);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(699, 340);
            this.panel3.TabIndex = 11;
            // 
            // gridCtrlGT
            // 
            this.gridCtrlGT.DataSource = this.prdGrupoTrabajoDetalleInfoBindingSource;
            this.gridCtrlGT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridCtrlGT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridCtrlGT.Location = new System.Drawing.Point(0, 0);
            this.gridCtrlGT.MainView = this.gridViewGT;
            this.gridCtrlGT.Name = "gridCtrlGT";
            this.gridCtrlGT.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemHyperLinkEdit1,
            this.repositoryItemHyperLinkEdit2,
            this.repositoryItemPictureEdit1,
            this.repositoryItemPictureEdit2,
            this.repository_Producto,
            this.cmb_empleado,
            this.cmb_estado});
            this.gridCtrlGT.Size = new System.Drawing.Size(699, 340);
            this.gridCtrlGT.TabIndex = 8;
            this.gridCtrlGT.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewGT});
            // 
            // prdGrupoTrabajoDetalleInfoBindingSource
            // 
            this.prdGrupoTrabajoDetalleInfoBindingSource.DataSource = typeof(Core.Erp.Info.Produc_Cirdesus.prd_GrupoTrabajoDetalle_Info);
            // 
            // gridViewGT
            // 
            this.gridViewGT.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colIdEmpresa,
            this.colIdSucursal,
            this.colCodObra,
            this.gridColumn1,
            this.colIdEmpleado,
            this.colIdGrupotrabajo,
            this.colNombreCompleto,
            this.colObservacion,
            this.colSecuencia});
            this.gridViewGT.GridControl = this.gridCtrlGT;
            this.gridViewGT.Name = "gridViewGT";
            this.gridViewGT.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewGT.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewGT.OptionsSelection.MultiSelect = true;
            this.gridViewGT.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridViewGT.OptionsView.ShowGroupPanel = false;
            this.gridViewGT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridViewGT_KeyDown);
            // 
            // colIdEmpresa
            // 
            this.colIdEmpresa.FieldName = "IdEmpresa";
            this.colIdEmpresa.Name = "colIdEmpresa";
            // 
            // colIdSucursal
            // 
            this.colIdSucursal.FieldName = "IdSucursal";
            this.colIdSucursal.Name = "colIdSucursal";
            // 
            // colCodObra
            // 
            this.colCodObra.FieldName = "CodObra";
            this.colCodObra.Name = "colCodObra";
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Empleado";
            this.gridColumn1.ColumnEdit = this.cmb_empleado;
            this.gridColumn1.FieldName = "IdEmpleado";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 408;
            // 
            // cmb_empleado
            // 
            this.cmb_empleado.AutoHeight = false;
            this.cmb_empleado.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmb_empleado.DataSource = this.roEmpleadoInfoBindingSource;
            this.cmb_empleado.DisplayMember = "NomCompleto";
            this.cmb_empleado.Name = "cmb_empleado";
            this.cmb_empleado.ValueMember = "IdEmpleado";
            this.cmb_empleado.View = this.gridView1;
            // 
            // roEmpleadoInfoBindingSource
            // 
            this.roEmpleadoInfoBindingSource.DataSource = typeof(Core.Erp.Info.Roles.ro_Empleado_Info);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colIdEmpleado1,
            this.colpe_nombreCompleto});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // colIdEmpleado1
            // 
            this.colIdEmpleado1.Caption = "Id";
            this.colIdEmpleado1.FieldName = "IdEmpleado";
            this.colIdEmpleado1.Name = "colIdEmpleado1";
            this.colIdEmpleado1.Visible = true;
            this.colIdEmpleado1.VisibleIndex = 1;
            this.colIdEmpleado1.Width = 160;
            // 
            // colpe_nombreCompleto
            // 
            this.colpe_nombreCompleto.Caption = "Empleado";
            this.colpe_nombreCompleto.FieldName = "NomCompleto";
            this.colpe_nombreCompleto.Name = "colpe_nombreCompleto";
            this.colpe_nombreCompleto.Visible = true;
            this.colpe_nombreCompleto.VisibleIndex = 0;
            this.colpe_nombreCompleto.Width = 934;
            // 
            // colIdEmpleado
            // 
            this.colIdEmpleado.FieldName = "IdEmpleado";
            this.colIdEmpleado.Name = "colIdEmpleado";
            // 
            // colIdGrupotrabajo
            // 
            this.colIdGrupotrabajo.FieldName = "IdGrupotrabajo";
            this.colIdGrupotrabajo.Name = "colIdGrupotrabajo";
            // 
            // colNombreCompleto
            // 
            this.colNombreCompleto.FieldName = "NombreCompleto";
            this.colNombreCompleto.Name = "colNombreCompleto";
            this.colNombreCompleto.Width = 210;
            // 
            // colObservacion
            // 
            this.colObservacion.FieldName = "Observacion";
            this.colObservacion.Name = "colObservacion";
            this.colObservacion.Visible = true;
            this.colObservacion.VisibleIndex = 1;
            this.colObservacion.Width = 498;
            // 
            // colSecuencia
            // 
            this.colSecuencia.FieldName = "Secuencia";
            this.colSecuencia.Name = "colSecuencia";
            this.colSecuencia.OptionsColumn.ShowCaption = false;
            this.colSecuencia.Width = 83;
            // 
            // repositoryItemHyperLinkEdit1
            // 
            this.repositoryItemHyperLinkEdit1.AutoHeight = false;
            this.repositoryItemHyperLinkEdit1.Caption = "Descargar";
            this.repositoryItemHyperLinkEdit1.LinkColor = System.Drawing.Color.Blue;
            this.repositoryItemHyperLinkEdit1.Name = "repositoryItemHyperLinkEdit1";
            // 
            // repositoryItemHyperLinkEdit2
            // 
            this.repositoryItemHyperLinkEdit2.AutoHeight = false;
            this.repositoryItemHyperLinkEdit2.Name = "repositoryItemHyperLinkEdit2";
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.InitialImage = ((System.Drawing.Image)(resources.GetObject("repositoryItemPictureEdit1.InitialImage")));
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            this.repositoryItemPictureEdit1.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit1.ReadOnly = true;
            // 
            // repositoryItemPictureEdit2
            // 
            this.repositoryItemPictureEdit2.Name = "repositoryItemPictureEdit2";
            this.repositoryItemPictureEdit2.PictureInterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            this.repositoryItemPictureEdit2.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit2.ReadOnly = true;
            // 
            // repository_Producto
            // 
            this.repository_Producto.AutoHeight = false;
            this.repository_Producto.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repository_Producto.DisplayMember = "pr_codigo";
            this.repository_Producto.Name = "repository_Producto";
            this.repository_Producto.ValueMember = "IdProducto";
            this.repository_Producto.View = this.gridcombo;
            // 
            // gridcombo
            // 
            this.gridcombo.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4});
            this.gridcombo.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridcombo.Name = "gridcombo";
            this.gridcombo.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridcombo.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Codigo";
            this.gridColumn2.FieldName = "pr_codigo";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Descripcion";
            this.gridColumn3.FieldName = "pr_descripcion";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "ID";
            this.gridColumn4.FieldName = "IdProducto";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 0;
            // 
            // cmb_estado
            // 
            this.cmb_estado.AutoHeight = false;
            this.cmb_estado.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmb_estado.DisplayMember = "descripcion";
            this.cmb_estado.Name = "cmb_estado";
            this.cmb_estado.ValueMember = "Codigo";
            this.cmb_estado.View = this.repositoryItemSearchLookUpEdit2View;
            // 
            // repositoryItemSearchLookUpEdit2View
            // 
            this.repositoryItemSearchLookUpEdit2View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemSearchLookUpEdit2View.Name = "repositoryItemSearchLookUpEdit2View";
            this.repositoryItemSearchLookUpEdit2View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemSearchLookUpEdit2View.OptionsView.ShowGroupPanel = false;
            // 
            // ultraGridDetalle
            // 
            ultraGridColumn15.Header.Caption = "Empleado";
            ultraGridColumn15.Header.VisiblePosition = 1;
            ultraGridColumn15.Width = 315;
            ultraGridColumn16.Header.VisiblePosition = 0;
            ultraGridColumn16.Width = 65;
            ultraGridColumn17.Header.VisiblePosition = 2;
            ultraGridColumn17.Width = 296;
            ultraGridBand1.Columns.AddRange(new object[] {
            ultraGridColumn15,
            ultraGridColumn16,
            ultraGridColumn17});
            this.ultraGridDetalle.DisplayLayout.BandsSerializer.Add(ultraGridBand1);
            this.ultraGridDetalle.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            this.ultraGridDetalle.Location = new System.Drawing.Point(0, 0);
            this.ultraGridDetalle.Name = "ultraGridDetalle";
            this.ultraGridDetalle.Size = new System.Drawing.Size(699, 138);
            this.ultraGridDetalle.TabIndex = 0;
            this.ultraGridDetalle.Text = "DETALLE DEL GRUPO";
            this.ultraGridDetalle.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.ultraGridDetalle_InitializeLayout);
            this.ultraGridDetalle.AfterRowInsert += new Infragistics.Win.UltraWinGrid.RowEventHandler(this.ultraGridDetalle_AfterRowInsert);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panelSucursal);
            this.panel2.Controls.Add(this.PanelObra);
            this.panel2.Controls.Add(this.chkEstado);
            this.panel2.Controls.Add(this.ultraCmbEModeloProductivo);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txt_numGrupo);
            this.panel2.Controls.Add(this.lblAnulado);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.UltraCmbOrdenTaller);
            this.panel2.Controls.Add(this.ultraCmbELiderGrupo);
            this.panel2.Controls.Add(this.ultraCmbEEtapaProduccion);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txt_nomGrupo);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(699, 144);
            this.panel2.TabIndex = 10;
            // 
            // panelSucursal
            // 
            this.panelSucursal.Location = new System.Drawing.Point(0, 33);
            this.panelSucursal.Name = "panelSucursal";
            this.panelSucursal.Size = new System.Drawing.Size(360, 24);
            this.panelSucursal.TabIndex = 1;
            // 
            // PanelObra
            // 
            this.PanelObra.Location = new System.Drawing.Point(0, 60);
            this.PanelObra.Name = "PanelObra";
            this.PanelObra.Size = new System.Drawing.Size(360, 22);
            this.PanelObra.TabIndex = 2;
            // 
            // chkEstado
            // 
            this.chkEstado.AutoSize = true;
            this.chkEstado.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkEstado.Checked = true;
            this.chkEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEstado.Location = new System.Drawing.Point(625, 1);
            this.chkEstado.Name = "chkEstado";
            this.chkEstado.Size = new System.Drawing.Size(59, 17);
            this.chkEstado.TabIndex = 17;
            this.chkEstado.Text = "Activo:";
            this.chkEstado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkEstado.UseVisualStyleBackColor = true;
            this.chkEstado.Visible = false;
            // 
            // ultraCmbEModeloProductivo
            // 
            this.ultraCmbEModeloProductivo.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.ultraCmbEModeloProductivo.Enabled = false;
            this.ultraCmbEModeloProductivo.HideSelection = false;
            this.ultraCmbEModeloProductivo.Location = new System.Drawing.Point(467, 59);
            this.ultraCmbEModeloProductivo.Name = "ultraCmbEModeloProductivo";
            this.ultraCmbEModeloProductivo.Size = new System.Drawing.Size(220, 21);
            this.ultraCmbEModeloProductivo.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(366, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Modelo Producción:";
            // 
            // txt_numGrupo
            // 
            this.txt_numGrupo.Enabled = false;
            this.txt_numGrupo.Location = new System.Drawing.Point(66, 8);
            this.txt_numGrupo.Name = "txt_numGrupo";
            this.txt_numGrupo.Size = new System.Drawing.Size(136, 20);
            this.txt_numGrupo.TabIndex = 1;
            // 
            // lblAnulado
            // 
            this.lblAnulado.AutoSize = true;
            this.lblAnulado.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAnulado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnulado.ForeColor = System.Drawing.Color.Red;
            this.lblAnulado.Location = new System.Drawing.Point(266, 116);
            this.lblAnulado.Name = "lblAnulado";
            this.lblAnulado.Size = new System.Drawing.Size(174, 17);
            this.lblAnulado.TabIndex = 11;
            this.lblAnulado.Text = "** GRUPO INACTIVO **";
            this.lblAnulado.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "#Registro:";
            // 
            // UltraCmbOrdenTaller
            // 
            this.UltraCmbOrdenTaller.Location = new System.Drawing.Point(467, 32);
            this.UltraCmbOrdenTaller.Name = "UltraCmbOrdenTaller";
            this.UltraCmbOrdenTaller.Size = new System.Drawing.Size(220, 21);
            this.UltraCmbOrdenTaller.TabIndex = 3;
            this.UltraCmbOrdenTaller.AfterExitEditMode += new System.EventHandler(this.ultraCmbELiderGrupo_AfterExitEditMode);
            this.UltraCmbOrdenTaller.Validating += new System.ComponentModel.CancelEventHandler(this.ultraCmbELiderGrupo_Validating);
            // 
            // ultraCmbELiderGrupo
            // 
            this.ultraCmbELiderGrupo.Location = new System.Drawing.Point(66, 87);
            this.ultraCmbELiderGrupo.Name = "ultraCmbELiderGrupo";
            this.ultraCmbELiderGrupo.Size = new System.Drawing.Size(290, 21);
            this.ultraCmbELiderGrupo.TabIndex = 6;
            this.ultraCmbELiderGrupo.AfterExitEditMode += new System.EventHandler(this.ultraCmbELiderGrupo_AfterExitEditMode);
            this.ultraCmbELiderGrupo.Validating += new System.ComponentModel.CancelEventHandler(this.ultraCmbELiderGrupo_Validating);
            // 
            // ultraCmbEEtapaProduccion
            // 
            this.ultraCmbEEtapaProduccion.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains;
            this.ultraCmbEEtapaProduccion.Location = new System.Drawing.Point(467, 86);
            this.ultraCmbEEtapaProduccion.Name = "ultraCmbEEtapaProduccion";
            this.ultraCmbEEtapaProduccion.Size = new System.Drawing.Size(220, 21);
            this.ultraCmbEEtapaProduccion.TabIndex = 5;
            this.ultraCmbEEtapaProduccion.Validating += new System.ComponentModel.CancelEventHandler(this.ultraCmbEEtapaProduccion_Validating);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Grupo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Líder:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(366, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Orden Taller:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(366, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Etapa Producción:";
            // 
            // txt_nomGrupo
            // 
            this.txt_nomGrupo.Location = new System.Drawing.Point(66, 115);
            this.txt_nomGrupo.MaxLength = 150;
            this.txt_nomGrupo.Multiline = true;
            this.txt_nomGrupo.Name = "txt_nomGrupo";
            this.txt_nomGrupo.Size = new System.Drawing.Size(620, 22);
            this.txt_nomGrupo.TabIndex = 7;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 509);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(699, 22);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripMain
            // 
            this.toolStripMain.BackColor = System.Drawing.Color.White;
            this.toolStripMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator5,
            this.btnGrabar,
            this.toolStripSeparator1,
            this.btnGrabarySalir,
            this.toolStripSeparator3,
            this.btn_Imprimir,
            this.toolStripSeparator4,
            this.toolStripTextBox1,
            this.sep1,
            this.btn_Anular,
            this.toolStripSeparator2,
            this.mnu_salir,
            this.toolStripSeparator6});
            this.toolStripMain.Location = new System.Drawing.Point(0, 0);
            this.toolStripMain.Name = "toolStripMain";
            this.toolStripMain.Size = new System.Drawing.Size(699, 25);
            this.toolStripMain.TabIndex = 8;
            this.toolStripMain.Text = "toolStrip1";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // btnGrabar
            // 
            this.btnGrabar.Image = ((System.Drawing.Image)(resources.GetObject("btnGrabar.Image")));
            this.btnGrabar.Name = "btnGrabar";
            this.btnGrabar.Size = new System.Drawing.Size(62, 22);
            this.btnGrabar.Text = "Grabar";
            this.btnGrabar.Click += new System.EventHandler(this.btnGrabar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnGrabarySalir
            // 
            this.btnGrabarySalir.Image = ((System.Drawing.Image)(resources.GetObject("btnGrabarySalir.Image")));
            this.btnGrabarySalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGrabarySalir.Name = "btnGrabarySalir";
            this.btnGrabarySalir.Size = new System.Drawing.Size(103, 22);
            this.btnGrabarySalir.Text = "Guardar y Salir";
            this.btnGrabarySalir.Click += new System.EventHandler(this.btnGrabarySalir_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_Imprimir
            // 
            this.btn_Imprimir.Image = global::Core.Erp.Winform.Properties.Resources.imprimir;
            this.btn_Imprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Imprimir.Name = "btn_Imprimir";
            this.btn_Imprimir.Size = new System.Drawing.Size(73, 22);
            this.btn_Imprimir.Text = "Imprimir";
            this.btn_Imprimir.Click += new System.EventHandler(this.btn_Imprimir_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // mnu_salir
            // 
            this.mnu_salir.Image = ((System.Drawing.Image)(resources.GetObject("mnu_salir.Image")));
            this.mnu_salir.Name = "mnu_salir";
            this.mnu_salir.Size = new System.Drawing.Size(49, 22);
            this.mnu_salir.Text = "&Salir";
            this.mnu_salir.Click += new System.EventHandler(this.mnu_salir_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // sep1
            // 
            this.sep1.Name = "sep1";
            this.sep1.Size = new System.Drawing.Size(6, 25);
            this.sep1.Visible = false;
            // 
            // btn_Anular
            // 
            this.btn_Anular.Image = global::Core.Erp.Winform.Properties.Resources.eliminar;
            this.btn_Anular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Anular.Name = "btn_Anular";
            this.btn_Anular.Size = new System.Drawing.Size(62, 22);
            this.btn_Anular.Text = "Anular";
            this.btn_Anular.Visible = false;
            this.btn_Anular.Click += new System.EventHandler(this.btn_Anular_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 25);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // FrmPrd_GrupoTrabajoMantenimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(699, 531);
            this.Controls.Add(this.panel1);
            this.Name = "FrmPrd_GrupoTrabajoMantenimiento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mantenimiento de Grupos de Trabajo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmPrd_GrupoTrabajoMantenimiento_FormClosing);
            this.Load += new System.EventHandler(this.FrmPrd_GrupoTrabajoMantenimiento_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridCtrlGT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prdGrupoTrabajoDetalleInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_empleado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roEmpleadoInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repository_Producto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridcombo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmb_estado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit2View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGridDetalle)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraCmbEModeloProductivo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UltraCmbOrdenTaller)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraCmbELiderGrupo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraCmbEEtapaProduccion)).EndInit();
            this.toolStripMain.ResumeLayout(false);
            this.toolStripMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip toolStripMain;
        private System.Windows.Forms.ToolStripButton btnGrabar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnGrabarySalir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton mnu_salir;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblAnulado;
        private System.Windows.Forms.Label label1;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor ultraCmbELiderGrupo;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor ultraCmbEEtapaProduccion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_nomGrupo;
        private System.Windows.Forms.TextBox txt_numGrupo;
        private System.Windows.Forms.Label label7;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor ultraCmbEModeloProductivo;
        private Infragistics.Win.UltraWinGrid.UltraGrid ultraGridDetalle;
        private System.Windows.Forms.CheckBox chkEstado;
        private System.Windows.Forms.Panel PanelObra;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor UltraCmbOrdenTaller;
        private System.Windows.Forms.BindingSource prdGrupoTrabajoDetalleInfoBindingSource;
        private System.Windows.Forms.BindingSource roEmpleadoInfoBindingSource;
        private DevExpress.XtraGrid.GridControl gridCtrlGT;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewGT;
        private DevExpress.XtraGrid.Columns.GridColumn colIdEmpresa;
        private DevExpress.XtraGrid.Columns.GridColumn colIdSucursal;
        private DevExpress.XtraGrid.Columns.GridColumn colCodObra;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit cmb_empleado;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn colIdEmpleado1;
        private DevExpress.XtraGrid.Columns.GridColumn colpe_nombreCompleto;
        private DevExpress.XtraGrid.Columns.GridColumn colIdEmpleado;
        private DevExpress.XtraGrid.Columns.GridColumn colIdGrupotrabajo;
        private DevExpress.XtraGrid.Columns.GridColumn colNombreCompleto;
        private DevExpress.XtraGrid.Columns.GridColumn colObservacion;
        private DevExpress.XtraGrid.Columns.GridColumn colSecuencia;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryItemHyperLinkEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryItemHyperLinkEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repository_Producto;
        private DevExpress.XtraGrid.Views.Grid.GridView gridcombo;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit cmb_estado;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemSearchLookUpEdit2View;
        private System.Windows.Forms.ToolStripButton btn_Imprimir;
        private System.Windows.Forms.Panel panelSucursal;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator sep1;
        private System.Windows.Forms.ToolStripButton btn_Anular;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
    }
}